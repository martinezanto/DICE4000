# In this file write your unit tests. 
# I have set up the test class for you.
import unittest
import Cipher as target

class TestCipherTools(unittest.TestCase):
